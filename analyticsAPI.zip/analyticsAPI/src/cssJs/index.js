$(document).ready(function () {

    listPageana();
    function listPageana() {
        $.ajax({
            url: "./server/api.php?token=touki&call=getpageana",
            method: "GET",
            dataType: "json",
        })
            //Ce code sera exécuté en cas de succès - La réponse du serveur est passée à done()
            /*On peut par exemple convertir cette réponse en chaine JSON et insérer
             * cette chaine dans un div id="res"*/
            .done(function (response) {
                let data = JSON.stringify(response);
                let c = jQuery.parseJSON(data);

                let html = ' ';
                for (var i = 0; i < c.length; i++) {
                    html = html + 'id_pageana  ' + c[i].id_pageana + ' libelle_action ' + c[i].libelle_action + ' <br>'
                }
                $("#res").html(html);
            })

    }



    function detailsElement() {
        var idPageana = $('#idPageana').val();
        $.ajax({
            url: "./server/api.php?token=touki&call=getpageana&id=" + idPageana,
            method: "GET",
            dataType: "json",
        })
            .done(function (response) {
                let data = JSON.stringify(response);
                let c = jQuery.parseJSON(data);
                let html = ' ';
                for (var i = 0; i < c.length; i++) {
                    html = html + 'id_pageana  ' + c[i].id_pageana + ' libelle_action ' + c[i].libelle_action + ' <br>'
                }
                $("#details").html(html);
            })

    }

    $('#cherche').on('click', function () {
        detailsElement();
    })



    $('#suprime').on('click', function () {
        var idPageana = $('#idPageanasupresion').val();
        $.ajax({
            url: "./server/api.php?token=touki&call=deletepageana&id=" + idPageana,
            method: "GET",
            dataType: "json",
        })
            .done(function (response) {
                detailsElement();
                listPageana();
            })
    })










});



