
Auteurs : Aurelien Vallet - Alexis Escudero

Contexte : Développement d'un API REST dans le cadre de la M1 MIAGE

Description : Ce projet met à disposition une API REST permettant à un utilisateur d'intérragir
avec une base de donnée MySQL, la base de donnée contient des informations concernant des intéractions 
réalisées entre l'utilisateur et un site web, par éxemple, si l'utilisateur quitte la page d'acceuil du site
alors l'événement "quitter page" et la page "Accueil" seont enregistrées dans une table avec des informations
complémentaires comme l'IP de l'utilisateur, la date etc...