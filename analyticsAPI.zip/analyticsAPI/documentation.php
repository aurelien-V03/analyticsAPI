<!--page de recherche de patients, plusieurs filtres proposés-->

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>TP2 / API</title>
    <meta name="description" content="Alexis Escudero / Aurelien Vallet">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Sonsie+One" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="./src/bibliotheques/bootstrap.min.css">
    <script src="./src/bibliotheques/jquery.slim.min.js"> </script>
    <link rel="stylesheet" href="./src/cssJs/style.css">
    <script src="./src/bibliotheques/ajax.js"> </script>
    <script src="./src/cssJs/index.js"> </script>


</head>

<body>
    <div class="container-fluid">
        <header>
            <div class="row">
                <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                    <h1> API </h1>
                </div>
                <div class="col-lg-6 col-md-6 col-xs-6 col-sm-6">
                    <a href="documentation.php"> documentation </a>
                    <a href="index.php"> details API </a>
                </div>
            </div>


        </header>
        <main>
            <h1> documentation </h1>

        </main>
    </div>
</body>

</html>