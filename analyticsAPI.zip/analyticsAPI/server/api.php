<?php
include_once('db_connect.php');

$mysql_connection = new db_connection();

//Reception requete en GET
if (!empty($_GET)) {
    
    // Vérification de la présence du token et de sa validiter
    if( isset($_GET['token']) && $mysql_connection->verificationToken($_GET['token'])  ) {

   
        // Obtenir le détaille d'une trasanction
        if (isset($_GET['id']) &&  $_GET['call'] == 'getpageana') {
            return $mysql_connection->getPageanaById($_GET['id']);
        }

        // Obtenir le détaille de toutes les transactions
        if ($_GET['call'] == 'getpageana') {
            return $mysql_connection->getPageana();
        }

        // Suppresion d'une transaction
        if ($_GET['call'] == 'deletepageana' && isset($_GET['id'])  ) {
            return $mysql_connection->deletePageana( $_GET['id'] );
        }
    }
    
// Reception requete en POST
} else if(!empty($_POST)) {

    // Vérification de la présence du token et de sa validiter
    if( isset($_POST['token']) && $mysql_connection->verificationToken($_POST['token']) ) {

        // Ajouts d'une Pageana
        if (  isset($_POST['ip'])  &&    isset($_POST['id_utilisateur']) && isset($_POST['url'])  &&    isset($_POST['libelle_action']) ) {
            $mysql_connection->postPageana( $_POST['ip'] , $_POST['id_utilisateur'], $_POST['url'], 1, 1, $_POST['libelle_action']);
            header("Location: ../index.php");
        }

    }

    // Si pas de token mais nom et password alros inscriptions d'un utilsiateur
    if (  isset($_POST['nom'])  &&    isset($_POST['password']) ) {
        var_dump(  $mysql_connection->inscriptionsUtilisateur( $_POST['nom'], $_POST['password'] ) ) ;
    }

}

