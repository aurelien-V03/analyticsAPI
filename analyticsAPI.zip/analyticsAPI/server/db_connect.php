<?php
// La classe db_connection assure une connection avec la base de donnée
// MySQL, elle permet également de réaliser des opérations comme récupérer
// des données et en poster.
class db_connection {

    private $mysql_connection; // objet PDO
    private $user = "root";
    private $pass = "";
    private $host = "localhost";
    private $dbname = "analytics_api";

    // Constructeur 
    public function __construct() {
        // Connection bdd 
        try {
            $this->mysql_connection = new PDO('mysql:host=' . $this->host . ';dbname=' . $this->dbname . ';charset=utf8', $this->user, $this->pass);
        } catch (Exception $e) {
            die('Erreur connexion MySQL : ' . $e->getMessage());  //On définit le mode d'erreur de PDO sur Exception
        }
    }


    // Récupère toutes les occurrences de la table “pageana”
    // et affiche le JSON des occurrences 
    public function getPageana(){
        $request = "SELECT id_pageana, ip, id_utilisateur, url, code_ecran, code_action, libelle_action, date_enreg FROM pageana";
        $responseJson = [];
        $request_prepared = $this->mysql_connection->prepare($request);
        $request_prepared->execute();

        while ($request_row = $request_prepared->fetch()) {
            $responseJson[] = $request_row;
        }
        $this->affichageJson($responseJson);
    }

    // Récupère l'occurrences de la table “pageana” avec $id
    // et affiche le JSON de cette occurrence
    public function getPageanaById($id)  {
        $request = "SELECT * FROM pageana WHERE id_pageana = ?";
        $responseJson = [];
        $request_prepared = $this->mysql_connection->prepare($request);
        $request_prepared->execute(array($id));

        $request_row = $request_prepared->fetch();
        $responseJson[] = $request_row;
        $this->affichageJson($responseJson);
    }

    // ajoute une occurrence dans la table pageana
    public function postPageana($ip, $id_utilisateur, $url, $code_ecran, $code_action, $libelle_action) {
        $request = "INSERT INTO pageana(ip,id_utilisateur,url,code_ecran,code_action,libelle_action,date_enreg) VALUES(?,?,?,?,?,?,?)";
        $request_prepared = $this->mysql_connection->prepare($request);

        // Si la requete a été executée avec succes 
        if ($request_prepared->execute(array($ip, $id_utilisateur, $url, $code_ecran, $code_action, $libelle_action, date("j/ n/ Y")))) {
            $responseJson =  array(
                'status' => 'Ajout dans la table pageana avec succes'
            );
        }
        // Si la requete n'a pas pu etre executée
        else {
            $responseJson =  array(
                'status' => 'Erreur lors de l\'ajout dans la table pageana'
            );
        }
        $this->affichageJson($responseJson);
    }

    // supprime une occurrence dans la table pageana
    public function deletePageana($id) {
        $request = "delete from pageana where id_pageana = ?";
        $request_prepared = $this->mysql_connection->prepare($request);

        if ($request_prepared->execute(array($id))) {
            $responseJson =  array(
                'status' => 'Suppression dans la table pageana avec succes'
            );
        } else {
            $responseJson =  array(
                'status' => 'Erreur lors de la suppression dans la table pageana echec'
            );
        }
        $this->affichageJson($responseJson);
    }


    // affichage du json
    private function affichageJson($responseJson) {
        header('Content-Type: application/json');
        echo json_encode($responseJson, JSON_PRETTY_PRINT);
    }


    // On vérifie si le token envoyer par le client existe bien en bdd
    public function verificationToken($token){
        $request_prepared = $this->mysql_connection->prepare("Select token from user where token = ?");
        if ($request_prepared->execute(array($token))) { return $request_prepared;    } 
        return false;
    }


    // On inscript un utilisateur avec sont nom et prenom. Une fois fais on lui renvoie sont token généré automatiquement
    public function inscriptionsUtilisateur($nom, $password){
        $token = substr(strtr(base64_encode(hex2bin($this->RandomToken(32))), '+', '.'), 0, 44);
        $request_prepared = $this->mysql_connection->prepare("INSERT INTO user(nom, password, token)  VALUES(?,?,?)");
        if ($request_prepared->execute(array($nom, $password, $token ) )) { return $token; } 
        return false;
    }

    // Creation d'un token automatiquement
    private function RandomToken($length = 32){
        if (!isset($length) || intval($length) <= 8) {   $length = 32; }
        if (function_exists('random_bytes')) { return bin2hex(random_bytes($length)); }
        if (function_exists('mcrypt_create_iv')) {     return bin2hex(mcrypt_create_iv($length, MCRYPT_DEV_URANDOM)); }
        if (function_exists('openssl_random_pseudo_bytes')) {     return bin2hex(openssl_random_pseudo_bytes($length)); }
    }

 

    

}
